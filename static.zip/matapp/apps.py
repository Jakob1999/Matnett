from django.apps import AppConfig


class MatappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'matapp'
