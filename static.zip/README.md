# Matnett
-For å initialisere prosjektet første gang
-python -m venv venv
-pip install -r requirements.txt

