
## Hvorfor de merges
..kort info skrives inn her..

## Issues knyttet til merge requesten 
..skriv #nummerpåissue her.. 

